using System.Data;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using QuizApplication.Models;

namespace QuizApplication.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private IConfiguration configuration;
        public HomeController(IConfiguration _configuration)
        {
            configuration = _configuration;
        }

        public IActionResult Index()
        {
            string connectionString = this.configuration.GetConnectionString("ConnectionString");
            SqlConnection connection = new(connectionString);
            connection.Open();
            SqlCommand command = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "PR_MST_Quiz_Count";
            SqlDataReader reader = command.ExecuteReader();
            DataTable table = new();
            table.Load(reader);

            //Quiz Count

            foreach(DataRow dataRow in table.Rows)
            {
                TempData["QuizCount"] = dataRow["Count"];
            }


            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "PR_MST_Question_Count";
            reader = command.ExecuteReader();
            table = new();
            table.Load(reader);

            //Question Count

            foreach (DataRow dataRow in table.Rows)
            {
                TempData["QuestionCount"] = dataRow["Count"];
            }

            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "PR_MST_QuestionLevel_Count";
            reader = command.ExecuteReader();
            table = new();
            table.Load(reader);

            //QuestionLevel Count

            foreach (DataRow dataRow in table.Rows)
            {
                TempData["QuestionLevelCount"] = dataRow["Count"];
            }
            return View();

        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
