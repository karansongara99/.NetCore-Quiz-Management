﻿using System.Data;
using AddressBook.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace AddressBook.Controllers
{
    public class CountryController : Controller
    {
        private readonly IConfiguration configuration;

        public CountryController(IConfiguration configuration)
        {
            this.configuration = configuration;
        }
        public IActionResult CountryForm(int CountryID)
        {
            if (CountryID == 0)
            {
                TempData["PageTitle"] = "Add Country";
            }
            else
            {
                TempData["PageTitle"] = "Edit Country";
            }

            ViewBag.CustomerID = CountryID;
            string connectionString = this.configuration.GetConnectionString("ConnectionString");
            SqlConnection sqlConnection1 = new SqlConnection(connectionString);
            sqlConnection1.Open();
            SqlCommand sqlCommand1 = sqlConnection1.CreateCommand();
            sqlCommand1.CommandType = CommandType.StoredProcedure;
            sqlCommand1.CommandText = "PR_User_SelectAll";
            SqlDataReader reader1 = sqlCommand1.ExecuteReader();
            DataTable dataTable1 = new DataTable();
            dataTable1.Load(reader1);
            List<UserDropDownModel> userList = new List<UserDropDownModel>();
            foreach (DataRow data in dataTable1.Rows)
            {
                UserDropDownModel userDropDownModel = new UserDropDownModel();
                userDropDownModel.UserID = Convert.ToInt32(data["UserID"]);
                userDropDownModel.UserName = data["UserName"].ToString();
                userList.Add(userDropDownModel);
            }
            ViewBag.UserList = userList;

            SqlConnection sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();
            SqlCommand sqlCommand = sqlConnection.CreateCommand();
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.CommandText = "PR_Country_SelectByPK";
            sqlCommand.Parameters.AddWithValue("@CountryID", CountryID);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            DataTable table = new DataTable();
            table.Load(reader);
            CountryModel countryModel = new CountryModel();

            foreach (DataRow dataRow in table.Rows)
            {
                countryModel.CountryID = Convert.ToInt32(@dataRow["CountryID"]);
                countryModel.CountryName = @dataRow["CountryName"].ToString();
                countryModel.CountryCode = @dataRow["CountryCode"].ToString();
                countryModel.UserID = Convert.ToInt32(@dataRow["UserID"]);
            }

            return View("CountryForm", countryModel);

        }

        public IActionResult CountryList()
        {
            string connectionString = this.configuration.GetConnectionString("ConnectionString");
            SqlConnection connection = new(connectionString);
            connection.Open();
            SqlCommand command = connection.CreateCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "PR_Country_SelectAll";
            SqlDataReader reader = command.ExecuteReader();
            DataTable table = new();
            table.Load(reader);
            return View(table);
        }

        public IActionResult CountryDelete(int CountryID)
        {
            TempData["Notify"] = "deleted";

            try
            {
                string connectionString = this.configuration.GetConnectionString("ConnectionString");
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "PR_Country_DeleteByPk";
                command.Parameters.Add("@CountryID", SqlDbType.Int).Value = CountryID;

                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = ex.Message;
                Console.WriteLine(ex.ToString());
            }

            return RedirectToAction("CountryList");
        }


        public IActionResult CountrySave(CountryModel model)
        {
            if (ModelState.IsValid)
            {
                string connectionString = this.configuration.GetConnectionString("ConnectionString");
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                if (model.CountryID == 0)
                {
                    command.CommandText = "PR_Country_Insert";
                    command.Parameters.Add("@CreationDate", SqlDbType.DateTime).Value = DateTime.Now;
                }
                else
                {
                    command.CommandText = "PR_Country_UpdateByPk";
                    command.Parameters.Add("@CountryID", SqlDbType.Int).Value = model.CountryID;
                }
                command.Parameters.Add("@CountryName", SqlDbType.VarChar).Value = model.CountryName;
                command.Parameters.Add("@CountryCode", SqlDbType.VarChar).Value = model.CountryCode;
                command.Parameters.Add("@UserID", SqlDbType.Int).Value = model.UserID;
                command.ExecuteNonQuery();
                return RedirectToAction("CountryList");
            }
            return View("CountryForm", model);
        }

    }
}
